## Report Card of List Of Students

- Execute the script as follows
    - python main.py

- The main idea of the project is to to calculate the weighted average of the courses taken by each student. Each      report consists of the total average grade of all the courses, along with the course name and the teacher. It is a   generic project which is used to generate reports in every school and college.